package com.amdocsproj.bankproj;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InsertValidity {
    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
    private static final String USER = "sonali";
    private static final String PASSWORD = "root";

    public static void main(String[] args) {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            System.exit(1);
        }

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
            insertIntoValidTrans(connection);
            insertIntoInvalidTrans(connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void insertIntoValidTrans(Connection connection) throws SQLException {
        String insertQuery = "INSERT INTO ValidTrans(TransId, TransType, TransAmt, ValidMessage) " +
                "SELECT TransId, TransType, TransAmt, 'Valid' FROM Transaction WHERE TransStat = 'Valid'";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Inserted into ValidTrans table.");
            } else {
                System.out.println("No rows to insert into ValidTrans table.");
            }
        }
    }

    private static void insertIntoInvalidTrans(Connection connection) throws SQLException {
        String insertQuery = "INSERT INTO InvalidTrans(TransId, TransType, TransAmt) " +
                "SELECT TransId, TransType, TransAmt FROM Transaction WHERE TransStat = 'Invalid'";
        try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Inserted into InvalidTrans table.");
            } else {
                System.out.println("No rows to insert into InvalidTrans table.");
            }
        }
    }
}

