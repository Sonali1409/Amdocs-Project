package com.amdocsproj.bankproj;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;



	public class updateNewBal {
	    // JDBC URL, username, and password of your database
	    private static final String URL = "jdbc:oracle:thin:@localhost:1521:XE";
	    private static final String USER = "sonali";
	    private static final String PASSWORD = "root";

	    public static void main(String[] args) {
	        // Scanner for user input
	        Scanner scanner = new Scanner(System.in);
	        
	        
	        try {
	            // Load the Oracle JDBC driver
	            Class.forName("oracle.jdbc.driver.OracleDriver");
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	            System.exit(1); // Exit the program if the driver is not found
	        }


	        // Parameters
	        System.out.print("Enter the TransId you want to update: ");
	        String transId = scanner.nextLine();

	        // Update database using JDBC
	        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
	            // Check if the TransId exists
	            if (isTransIdExists(connection, transId)) {
	                // Prepare update statement
	                String updateQuery = "UPDATE Transaction SET NewBal = OldBal + TransAmt, TransStat = "
	                        + "CASE WHEN OldBal + TransAmt >= 0 AND TransType = 'Deposit' THEN 'Valid' ELSE 'Invalid' END "
	                        + "WHERE TransId = ?";

	                try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
	                    // Set parameter
	                    preparedStatement.setString(1, transId);

	                    // Execute update
	                    int rowsAffected = preparedStatement.executeUpdate();

	                    if (rowsAffected > 0) {
	                        System.out.println("Update successful.");
	                    } else {
	                        System.out.println("No rows updated. Check if the provided TransId exists.");
	                    }
	                }
	            } else {
	                System.out.println("Provided TransId does not exist.");
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Close the scanner
	            scanner.close();
	        }
	    }

	    // Check if the TransId exists in the Transactions table
	    private static boolean isTransIdExists(Connection connection, String transId) throws SQLException {
	        String query = "SELECT COUNT(*) FROM Transaction WHERE TransId = ?";
	        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
	            preparedStatement.setString(1, transId);
	            try (ResultSet resultSet = preparedStatement.executeQuery()) {
	                resultSet.next();
	                return resultSet.getInt(1) > 0;
	            }
	        }
	    }
	}